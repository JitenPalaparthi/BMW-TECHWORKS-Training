

helm package demo-root-charts

helm repo index . \
  --url https://jitenpalaparthi.github.io/demo-root-charts

helm repo add jiten-demo \
  https://jitenpalaparthi.github.io/demo-root-charts

helm install demo-release \
  jiten-demo/demo-root-charts


.nojekyll
index.yaml
demo-root-charts-0.1.0.tgz
